
public class Timecode {
	public static String fromSeconds(double seconds){
		// Place your code here...
		// Hint: Check String's methods to see if there is a printf equivalent:
		//     https://docs.oracle.com/en/java/javase/21/docs/api/java.base/java/lang/String.html

		return "";
	}
}
