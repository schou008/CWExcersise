// Rational approximation
class RationalApx {
	int num;	// numerator
	int den;	// denominator
	int prec;	// how many decimal places the approximation is good out to
	
	RationalApx(){ this(0,1, 0); }
	
	RationalApx(int n, int d, int p){
		num = n;
		den = d;
		prec = p;
	}

	boolean equals(int n, int d, int p){
		return num==n && den==d && prec==p;
	}

	boolean equals(RationalApx other){
		return equals(other.num, other.den, other.prec);
	}
}

public class FindingPi {
	public static RationalApx run(int maxInt){
		var result = new RationalApx();

		// Place your code here...

		return result;
	}
}
