import java.util.Scanner;

public class EnterTheData {
	public static void run(Scanner scan){
		// Place your code here...
	}
}
